import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'cam2.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
//import 'package:dio/dio.dart';
import 'dart:convert' as convert;
import 'package:camera/camera.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';

void main() {
  runApp(CameraScreen());
}

class CameraScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return CameraScreenState();
  }
}

class CameraScreenState extends State {
  CameraController controller;
  List cameras;
  int selectedCameraId; // 0 is for back camera and 1 is for front camera

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text('Click The Subject'),
      ),
      body: Container(
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Expanded(
                flex: 1,
                child: previewCameraWidget(context),
              ),
              SizedBox(
                height: 10.0,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  cameraControlWidget(context),
                ],
              ),
              SizedBox(
                height: 10.0,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget previewCameraWidget(context) {
    if (controller == null || !controller.value.isInitialized) {
      return Container(
        child: Text('Camera controller is not initialized'),
      );
    } else {
      return AspectRatio(
        aspectRatio: controller.value.aspectRatio,
        child: CameraPreview(controller),
      );
    }
  }

  Widget cameraControlWidget(context) {
    return Expanded(
      child: Align(
        alignment: Alignment.center,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          mainAxisSize: MainAxisSize.max,
          children: <Widget>[
            FloatingActionButton(
              child: Icon(Icons.camera),
              onPressed: () {
                navigateToPreviewImage(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  void initState() {
    availableCameras().then((availableCameras) {
      cameras = availableCameras;

      if (cameras.length > 1) {
        selectedCameraId = 0;

        setState(() {});

        initialiseCamera(cameras[selectedCameraId]);
      }
    });
  }

  Future initialiseCamera(CameraDescription cameraDescription) async {
    if (controller != null) {
      await controller.dispose();
    }

    controller = CameraController(cameraDescription, ResolutionPreset.high);

    controller.addListener(() {
      if (mounted) {
        setState(() {});
      }
    });

    try {
      await controller.initialize();
    } on CameraException catch (e) {}
  }

  void navigateToPreviewImage(context) async {
    final imagePath =
        join((await getTemporaryDirectory()).path, '${DateTime.now()}.png');
    await controller.takePicture(imagePath);
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => CameraScreen2(
                  imagePathReceived1: imagePath,
                )));
  }
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() {
    return _MyAppState();
  }
}

class _MyAppState extends State<MyApp> {
  File _image;
  var data;
  final picker = ImagePicker();
  TextEditingController nameController = new TextEditingController();
  TextEditingController email = new TextEditingController();
  TextEditingController number = new TextEditingController();
  TextEditingController skills = new TextEditingController();
  TextEditingController education = new TextEditingController();
  TextEditingController links = new TextEditingController();
  TextEditingController experience = new TextEditingController();
  TextEditingController transcript = new TextEditingController();
  Future _getImage() async {
    var image = await picker.getImage(source: ImageSource.gallery);
    setState(() {
      _image = File(image.path);
    });

    String base64Image;
    //Response response;
    List<int> imageBytes = await _image.readAsBytes();
    base64Image = base64Encode(imageBytes);
    // print(base64Image);
    /* response =+
        await dio.post("http://127.0.0.1:5000/", data: {"image": base64Image});*/

    var url = 'http://127.0.0.1:5000/';
    var response = await http.post(
      url,
      body: {"image": " ${base64Image}"},
    );
    var jsonResponse = convert.jsonDecode(response.body);
    //print(jsonResponse['total_experience']);
    setState(() {
      nameController.text = jsonResponse['name'];
      skills.text = jsonResponse['skills'].toString();
      number.text = jsonResponse['mobile_number'];
      email.text = jsonResponse['email'];
      education.text = jsonResponse['Education'];
      links.text = jsonResponse['Links'].toString();
      experience.text = jsonResponse['experience'].toString();
      transcript.text = jsonResponse['transcript'].toString();
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Create Data Example',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
          appBar: AppBar(
            title: Text('Create Data Example'),
          ),
          body: ListView(
            children: <Widget>[
              RaisedButton(
                child: Icon(
                  Icons.camera_alt,
                  color: Colors.redAccent,
                ),
                onPressed: this._getImage,
                color: Colors.white,
              ),
              TextField(
                controller: nameController,
                decoration: InputDecoration(
                  hintText: 'Enter Name',
                  contentPadding: EdgeInsets.only(left: 10, right: 10, top: 10),
                ),
              ),
              TextField(
                controller: number,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  hintText: 'Enter Phone Number',
                  contentPadding: EdgeInsets.only(left: 10, right: 10, top: 10),
                ),
              ),
              TextField(
                controller: email,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  hintText: 'Enter e-mail',
                  contentPadding: EdgeInsets.only(left: 10, right: 10, top: 10),
                ),
              ),
              TextField(
                controller: skills,
                maxLines: null,
                decoration: InputDecoration(
                  hintText: 'Enter skills',
                  contentPadding: EdgeInsets.only(left: 10, right: 10, top: 10),
                ),
              ),
              TextField(
                controller: education,
                maxLines: null,
                decoration: InputDecoration(
                  hintText: 'Enter Education',
                  contentPadding: EdgeInsets.only(left: 10, right: 10, top: 10),
                ),
              ),
              TextField(
                controller: experience,
                maxLines: null,
                decoration: InputDecoration(
                  hintText: 'Enter experience',
                  contentPadding: EdgeInsets.only(left: 10, right: 10, top: 10),
                ),
              ),
              TextField(
                controller: links,
                maxLines: null,
                decoration: InputDecoration(
                  hintText: 'profile links',
                  contentPadding: EdgeInsets.only(left: 10, right: 10, top: 10),
                ),
              ),
              TextField(
                controller: transcript,
                maxLines: null,
                decoration: InputDecoration(
                  hintText: 'all details will appear here',
                  contentPadding: EdgeInsets.only(left: 10, right: 10, top: 10),
                ),
              ),
            ],
          )),
    );
  }
}
