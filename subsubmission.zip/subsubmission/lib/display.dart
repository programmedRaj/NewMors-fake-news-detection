import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'cam2.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
//import 'package:dio/dio.dart';
import 'dart:convert' as convert;
import 'package:camera/camera.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';

class Display extends StatefulWidget {
  String imagePathReceived1;
  String imagePathReceived2;

  Display({this.imagePathReceived1, this.imagePathReceived2});
  @override
  _DisplayState createState() => _DisplayState();
}

class _DisplayState extends State<Display> {
  String something = "";
  Future _getImage() async {
    String base64Image1;
    String base64Image2;

    //Response response;
    File _image1 = File(widget.imagePathReceived1);
    File _image2 = File(widget.imagePathReceived2);
    List<int> imageBytes1 = await _image1.readAsBytes();
    base64Image1 = base64Encode(imageBytes1);
    List<int> imageBytes2 = await _image2.readAsBytes();
    base64Image2 = base64Encode(imageBytes2);
    // print(base64Image);
    /* response =+
        await dio.post("http://127.0.0.1:5000/", data: {"image": base64Image});*/

    var url = 'http://10.0.2.2:5000/';
    var response = await http.post(
      url,
      body: {"image1": " ${base64Image1}", "image2": " ${base64Image2}"},
    );
    var jsonResponse = convert.jsonDecode(response.body);
    //print(jsonResponse['total_experience']);
    setState(() {
      something = jsonResponse;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(children: <Widget>[
        RaisedButton(onPressed: this._getImage),
        Text(something)
      ]),
    );
  }
}
