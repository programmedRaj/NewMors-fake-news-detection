package com.example.subsubmission

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
